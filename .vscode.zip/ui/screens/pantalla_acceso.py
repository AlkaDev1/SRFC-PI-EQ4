"""
ui/screens/pantalla_acceso.py

CAMBIOS:
  - Conectado a GestorIdioma: textos del HUD (OpenCV) y etiquetas
    de acceso concedido/info leen del idioma activo.
  - _limpiar() desregistra también el listener de idioma.
  - FIX: acceso denegado ahora se registra en la BD correctamente.
"""

import tkinter as tk
import threading
import queue
import cv2
import numpy as np
import math
import platform
from pathlib import Path
from PIL import Image, ImageTk
from datetime import datetime

from ui.styles import PALETA, FUENTES, MEDIDAS
from ui.components.barra_superior import crear_encabezado

try:
    import face_recognition
    FR_DISPONIBLE = True
except ImportError:
    FR_DISPONIBLE = False

_ES_RASPBERRY = platform.machine() in ("aarch64", "armv7l")
_CAM_INDEX    = 1 if _ES_RASPBERRY else 0

FRAMES_CONFIRMAR  = 8
FRAMES_PERDER     = 8
RES_PROCESAMIENTO = (320, 240)
SKIP_FRAMES       = 2
MAX_FRAMES_COLA   = 2


class PantallaAcceso:

    def __init__(self, parent, app):
        self.parent = parent
        self.app    = app

        self._p = app.tema.paleta() if hasattr(app, "tema") else _paleta_fallback()

        self._estado         = "escaneando"
        self._confianza      = 0.0
        self._bbox           = None
        self._photo          = None
        self._bloqueado      = False
        self._frames_ok      = 0
        self._frames_deny    = 0
        self._frames_perdido = 0
        self._angulo         = 0
        self._after_anim     = None
        self._after_reset    = None

        self._nombres   = []
        self._encodings = []
        self._cods      = []

        self._cargar_perfiles()

        self._cap             = None
        self._corriendo       = False
        self._cola_bio        = queue.Queue(maxsize=MAX_FRAMES_COLA)
        self._contador_frames = 0

        self._construir_ui()
        self._iniciar_animacion()
        self._abrir_camara()

        if hasattr(app, "tema"):
            app.tema.registrar(self._aplicar_tema)
        if hasattr(app, "idioma"):
            app.idioma.registrar(self._aplicar_idioma)

    # ── Helpers de idioma ─────────────────────────────────────────────────────
    def _t(self, clave, fallback=""):
        if hasattr(self.app, "idioma"):
            return self.app.idioma.t(clave, fallback)
        return fallback or clave

    def _msgs_hud(self):
        """Devuelve el dict de mensajes HUD según el idioma activo."""
        return {
            "escaneando":  (self._t("acceso.estado_escaneando_titulo", "POR FAVOR NO SE MUEVA"),
                            self._t("acceso.estado_escaneando_sub",    "ESCANEANDO ROSTRO...")),
            "detectado":   (self._t("acceso.estado_detectado_titulo",  "ROSTRO DETECTADO"),
                            self._t("acceso.estado_detectado_sub",     "Verificando identidad...")),
            "sin_rostro":  (self._t("acceso.estado_sin_rostro_titulo", "ACERCATE A LA CAMARA"),
                            self._t("acceso.estado_sin_rostro_sub",    "No se detecta ningun rostro")),
            "sin_camara":  (self._t("acceso.estado_sin_camara_titulo", "CAMARA NO DISPONIBLE"),
                            self._t("acceso.estado_sin_camara_sub",    "Verifique la conexion")),
            "acceso_deny": (self._t("acceso.estado_deny_titulo",       "ACCESO DENEGADO"),
                            self._t("acceso.estado_deny_sub",          "No autorizado")),
        }

    def _aplicar_idioma(self):
        """Actualiza los labels de la capa OK (el HUD OpenCV se actualiza solo en el loop)."""
        try:
            self._lbl_acceso_concedido.config(
                text=self._t("acceso.acceso_concedido", "ACCESO CONCEDIDO"))
            info_actual = self.lbl_info_ok.cget("text")
            if info_actual:
                hora = datetime.now().strftime("%I:%M %p").lower()
                self.lbl_info_ok.config(
                    text=self._t("acceso.acceso_registrado", "Acceso registrado · ") + hora)
        except tk.TclError:
            pass

    # ══════════════════════════════════════════
    #  Perfiles
    # ══════════════════════════════════════════
    def _cargar_perfiles(self):
        from core.database import inicializar_bd, cargar_todos_encodings
        inicializar_bd()
        perfiles = cargar_todos_encodings()
        self._encodings.clear()
        self._nombres.clear()
        self._cods.clear()
        for p in perfiles:
            self._encodings.append(p["encoding"])
            self._nombres.append(p["nombre"])
            self._cods.append(p["cod"])
        print(f"[ACCESO] {len(self._encodings)} perfiles cargados desde BD")

    # ══════════════════════════════════════════
    #  UI
    # ══════════════════════════════════════════
    def _construir_ui(self):
        p = self._p
        self.pantalla = tk.Frame(self.parent, bg=p["acceso_fondo"])
        self.pantalla.pack(fill="both", expand=True)

        ventana_principal = self.parent.winfo_toplevel()
        ventana_principal.protocol("WM_DELETE_WINDOW", self.ignorar_cierre)

        crear_encabezado(self.pantalla, self.app)

        self.contenedor = tk.Frame(self.pantalla, bg=p["acceso_fondo"])
        self.contenedor.pack(fill="both", expand=True)

        self._construir_capa_escaneo()
        self._construir_capa_ok()
        self._mostrar_capa("escaneo")

    def _crear_rect_redondeado(self, canvas, x1, y1, x2, y2, r, **kwargs):
        puntos = [x1+r, y1, x2-r, y1, x2, y1, x2, y1+r, x2, y2-r, x2, y2,
                  x2-r, y2, x1+r, y2, x1, y2, x1, y2-r, x1, y1+r, x1, y1]
        return canvas.create_polygon(puntos, smooth=True, **kwargs)

    def _crear_boton_volver(self, parent, bg_normal, bg_hover):
        w, h = 100, 60
        canvas = tk.Canvas(parent, width=w, height=h,
                           bg=parent["bg"], highlightthickness=0)
        rect_id = self._crear_rect_redondeado(
            canvas, 2, 2, w-2, h-2, 16,
            fill=bg_normal, outline="#ffffff", width=2)

        if not hasattr(self, '_img_return'):
            ruta = Path(__file__).resolve().parent.parent.parent / "assets" / "img" / "return_icon.png"
            try:
                self._img_return = tk.PhotoImage(file=str(ruta)) if ruta.exists() else None
            except Exception:
                self._img_return = None

        if self._img_return:
            content_id = canvas.create_image(w//2, h//2, image=self._img_return)
        else:
            content_id = canvas.create_text(w//2, h//2, text="←",
                                            fill="#ffffff", font=("Segoe UI", 20, "bold"))

        canvas.bind("<Enter>",    lambda e: canvas.itemconfig(rect_id, fill=bg_hover))
        canvas.bind("<Leave>",    lambda e: canvas.itemconfig(rect_id, fill=bg_normal))
        canvas.bind("<Button-1>", lambda e: self._volver())
        canvas.tag_bind(rect_id,    "<Button-1>", lambda e: self._volver())
        canvas.tag_bind(content_id, "<Button-1>", lambda e: self._volver())
        return canvas

    def _construir_capa_escaneo(self):
        p = self._p
        self.capa_escaneo = tk.Frame(self.contenedor, bg=p["acceso_fondo"])

        self.label_video = tk.Label(
            self.capa_escaneo, bg=p["acceso_fondo"],
            text=self._t("acceso.iniciando_camara", "Iniciando cámara..."),
            font=("Segoe UI", 13), fg=p["acceso_hud_fg"])
        self.label_video.place(x=0, y=0, relwidth=1, relheight=1)

        btn_volver = self._crear_boton_volver(
            self.capa_escaneo, bg_normal="#333333", bg_hover="#444444")
        btn_volver.place(x=14, rely=1.0, anchor="sw", y=-14)

        self.canvas_icono = tk.Canvas(
            self.capa_escaneo, width=44, height=44,
            bg=p["acceso_fondo"], highlightthickness=0)
        self.canvas_icono.place(relx=1.0, rely=1.0, anchor="se", x=-14, y=-14)

    def _construir_capa_ok(self):
        p     = self._p
        verde = p["acceso_ok_bg"]
        self.capa_ok = tk.Frame(self.contenedor, bg=verde)

        self.canvas_foto = tk.Canvas(
            self.capa_ok, width=120, height=120,
            bg=verde, highlightthickness=0)
        self.canvas_foto.place(relx=0.5, rely=0.22, anchor="center")

        self._badge_ok = tk.Label(
            self.capa_ok, text="✓",
            font=("Segoe UI", 14, "bold"),
            fg="#ffffff", bg=verde, padx=4, pady=2, relief="flat")
        self._badge_ok.place(relx=0.5, rely=0.22, anchor="sw", x=44, y=-4)

        self._lbl_acceso_concedido = tk.Label(
            self.capa_ok,
            text=self._t("acceso.acceso_concedido", "ACCESO CONCEDIDO"),
            font=("Segoe UI", 17, "bold"),
            fg=p["acceso_ok_texto"], bg=verde)
        self._lbl_acceso_concedido.place(relx=0.5, rely=0.52, anchor="center")

        self.lbl_nombre_ok = tk.Label(
            self.capa_ok, text="",
            font=("Segoe UI", 13, "bold"),
            fg=p["acceso_ok_texto"], bg=verde)
        self.lbl_nombre_ok.place(relx=0.5, rely=0.63, anchor="center")

        self.lbl_info_ok = tk.Label(
            self.capa_ok, text="",
            font=("Segoe UI", 9),
            fg=p["acceso_ok_texto"], bg=verde)
        self.lbl_info_ok.place(relx=0.5, rely=0.73, anchor="center")

        self._btn_volver_ok = self._crear_boton_volver(
            self.capa_ok, bg_normal="#2d7d32", bg_hover="#1b5e20")

    def _mostrar_capa(self, capa):
        if getattr(self, "_capa_actual", None) == capa:
            return
        self._capa_actual = capa
        for c in (self.capa_escaneo, self.capa_ok):
            c.place_forget()
        {"escaneo": self.capa_escaneo, "ok": self.capa_ok}[capa].place(
            x=0, y=0, relwidth=1, relheight=1)

    # ══════════════════════════════════════════
    #  Soporte de tema
    # ══════════════════════════════════════════
    def _aplicar_tema(self, p: dict):
        self._p = p
        try:
            self.pantalla.configure(bg=p["acceso_fondo"])
            self.contenedor.configure(bg=p["acceso_fondo"])
            self.capa_escaneo.configure(bg=p["acceso_fondo"])
            self.label_video.configure(bg=p["acceso_fondo"], fg=p["acceso_hud_fg"])
            self.canvas_icono.configure(bg=p["acceso_fondo"])
            self.capa_ok.configure(bg=p["acceso_ok_bg"])
            self.canvas_foto.configure(bg=p["acceso_ok_bg"])
            self._badge_ok.configure(bg=p["acceso_ok_bg"])
            self._lbl_acceso_concedido.configure(bg=p["acceso_ok_bg"],
                                                  fg=p["acceso_ok_texto"])
            self.lbl_nombre_ok.configure(bg=p["acceso_ok_bg"], fg=p["acceso_ok_texto"])
            self.lbl_info_ok.configure(bg=p["acceso_ok_bg"], fg=p["acceso_ok_texto"])
        except tk.TclError:
            pass

    # ══════════════════════════════════════════
    #  Cámara
    # ══════════════════════════════════════════
    def _abrir_camara(self):
        self._cap = cv2.VideoCapture(_CAM_INDEX)
        if not self._cap.isOpened():
            self._cambiar_estado("sin_camara")
            return
        self._cap.set(cv2.CAP_PROP_FRAME_WIDTH,  640)
        self._cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        self._cap.set(cv2.CAP_PROP_FPS, 30)
        self._cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        self._corriendo = True
        threading.Thread(target=self._hilo_camara,    daemon=True).start()
        threading.Thread(target=self._hilo_biometria, daemon=True).start()

    def _dibujar_texto_con_borde(self, img, texto, pos, fuente, escala,
                                  grosor_borde, grosor_texto, color_texto):
        cv2.putText(img, texto, pos, fuente, escala, (0,0,0), grosor_borde, cv2.LINE_AA)
        cv2.putText(img, texto, pos, fuente, escala, color_texto, grosor_texto, cv2.LINE_AA)

    def _hilo_camara(self):
        import time
        self._contador_frames = 0
        while self._corriendo:
            ok, frame = self._cap.read()
            if not ok:
                break
            frame = cv2.flip(frame, 1)
            self._contador_frames += 1

            if self._contador_frames % SKIP_FRAMES == 0:
                try:
                    self._cola_bio.put_nowait(frame.copy())
                except queue.Full:
                    pass

            if self._estado not in ("acceso_ok",):
                try:
                    cw = self.label_video.winfo_width()
                    ch = self.label_video.winfo_height()
                    if cw < 10 or ch < 10:
                        time.sleep(0.01)
                        continue

                    resized = cv2.resize(frame, (cw, ch),
                                         interpolation=cv2.INTER_NEAREST)

                    if self._bbox:
                        x1, y1, x2, y2 = self._bbox
                        color_bbox = (0,0,255) if self._estado == "acceso_deny" \
                                     else (80,175,76)
                        cv2.rectangle(resized, (x1,y1), (x2,y2), color_bbox, 2)

                    msgs   = self._msgs_hud()
                    titulo, sub = msgs.get(self._estado, ("ESCANEANDO...", ""))
                    fuente = cv2.FONT_HERSHEY_SIMPLEX
                    (wt, _), _ = cv2.getTextSize(titulo, fuente, 0.8, 2)
                    (ws, _), _ = cv2.getTextSize(sub,    fuente, 0.5, 1)
                    color_t = (0,0,255) if self._estado == "acceso_deny" else (255,255,255)
                    self._dibujar_texto_con_borde(resized, titulo, ((cw-wt)//2, 40),
                                                  fuente, 0.8, 5, 2, color_t)
                    self._dibujar_texto_con_borde(resized, sub, ((cw-ws)//2, 70),
                                                  fuente, 0.5, 3, 1, (200,200,200))

                    rgb   = cv2.cvtColor(resized, cv2.COLOR_BGR2RGB)
                    photo = ImageTk.PhotoImage(image=Image.fromarray(rgb))
                    self._photo = photo
                    self.label_video.after(0, self._pintar_frame)
                except Exception:
                    pass
            time.sleep(0)

    def _hilo_biometria(self):
        while self._corriendo:
            try:
                frame = self._cola_bio.get(timeout=1.0)
            except queue.Empty:
                continue
            resultado = self._reconocer(frame)
            try:
                self.label_video.after(0, lambda r=resultado: self._aplicar_resultado(r))
            except Exception:
                pass

    def _reconocer(self, frame):
        if FR_DISPONIBLE:
            pequeño = cv2.resize(frame, RES_PROCESAMIENTO,
                                 interpolation=cv2.INTER_LINEAR)
            rgb     = cv2.cvtColor(pequeño, cv2.COLOR_BGR2RGB)
            ubs     = face_recognition.face_locations(
                rgb, model="hog", number_of_times_to_upsample=0)
            if not ubs:
                return {"hay_rostro": False}
            ub = max(ubs, key=lambda u: (u[2]-u[0]) * (u[1]-u[3]))
            area_rostro = (ub[2]-ub[0]) * (ub[1]-ub[3])
            area_frame  = pequeño.shape[0] * pequeño.shape[1]
            if (area_rostro / area_frame) < 0.10:
                return {"hay_rostro": False}
            sy = frame.shape[0] / pequeño.shape[0]
            sx = frame.shape[1] / pequeño.shape[1]
            ub_orig = (int(ub[0]*sy), int(ub[1]*sx),
                       int(ub[2]*sy), int(ub[3]*sx))
            if not self._encodings:
                return {"hay_rostro": True, "reconocido": False,
                        "confianza": 0.0, "ubicacion": ub_orig,
                        "nombre": "", "cod": ""}
            encs = face_recognition.face_encodings(rgb, [ub], num_jitters=1)
            if not encs:
                return {"hay_rostro": True, "reconocido": False,
                        "confianza": 0.0, "ubicacion": ub_orig,
                        "nombre": "", "cod": ""}
            dists = face_recognition.face_distance(self._encodings, encs[0])
            idx   = int(np.argmin(dists))
            dist  = float(dists[idx])
            conf  = round(max(0.0, 1.0 - dist), 3)
            if dist <= 0.50:
                return {"hay_rostro": True, "reconocido": True,
                        "confianza": conf, "ubicacion": ub_orig,
                        "nombre": self._nombres[idx],
                        "cod":    self._cods[idx]}
            return {"hay_rostro": True, "reconocido": False,
                    "confianza": conf, "ubicacion": ub_orig,
                    "nombre": "", "cod": ""}
        else:
            gris    = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            cascade = cv2.CascadeClassifier(
                cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
            rostros = cascade.detectMultiScale(
                gris, scaleFactor=1.3, minNeighbors=5, minSize=(80,80))
            if len(rostros) == 0:
                return {"hay_rostro": False}
            x, y, w, h = max(rostros, key=lambda r: r[2]*r[3])
            if (w*h) / (frame.shape[0]*frame.shape[1]) < 0.10:
                return {"hay_rostro": False}
            return {"hay_rostro": True, "reconocido": False,
                    "confianza": 0.3, "ubicacion": (y, x+w, y+h, x),
                    "nombre": "", "cod": ""}

    def _pintar_frame(self):
        if self._photo is None:
            return
        self.label_video.imgtk = self._photo
        self.label_video.config(image=self._photo, text="")

    # ══════════════════════════════════════════
    #  Resultado biométrico
    # ══════════════════════════════════════════
    def _aplicar_resultado(self, r):
        if self._bloqueado:
            return
        if r.get("hay_rostro") and r.get("ubicacion"):
            top, right, bottom, left = r["ubicacion"]
            cw = self.label_video.winfo_width()
            ch = self.label_video.winfo_height()
            sx, sy = cw/640.0, ch/480.0
            self._bbox = (int(left*sx), int(top*sy),
                          int(right*sx), int(bottom*sy))
            self._frames_perdido = 0
        else:
            self._frames_perdido += 1
            if self._frames_perdido >= FRAMES_PERDER:
                self._bbox = None

        if not r.get("hay_rostro"):
            self._frames_ok = self._frames_deny = 0
            if self._frames_perdido >= FRAMES_PERDER:
                self._cambiar_estado("sin_rostro")
            return

        if r.get("reconocido"):
            self._frames_deny  = 0
            self._frames_ok   += 1
            self._cambiar_estado("detectado")
            if self._frames_ok >= FRAMES_CONFIRMAR:
                self._frames_ok = 0
                self._bloqueado = True
                self._cambiar_estado("acceso_ok",
                                     nombre=r.get("nombre", ""),
                                     cod=r.get("cod", ""))
        else:
            self._frames_ok    = 0
            self._frames_deny += 1
            self._cambiar_estado("detectado")
            if self._frames_deny >= FRAMES_CONFIRMAR:
                self._frames_deny = 0
                self._bloqueado   = True
                self._cambiar_estado("acceso_deny")
                self._after_reset = self.canvas_icono.after(2000, self._resetear)

    def _fin_secuencia_ok(self):
        self._volver()

    def _resetear(self):
        self._bloqueado = False
        self._bbox      = None
        self._cambiar_estado("escaneando")

    # ══════════════════════════════════════════
    #  Cambio de estado
    # ══════════════════════════════════════════
    def _cambiar_estado(self, estado, nombre="", cod=""):
        if self._estado == estado and estado not in ("acceso_ok", "acceso_deny"):
            return
        self._estado = estado
        p = self._p

        if estado == "acceso_ok":
            threading.Thread(target=self._gpio_acceso_ok, daemon=True).start()
            if cod:
                threading.Thread(target=self._registrar_acceso_bd,
                                  args=(cod,), daemon=True).start()
            self._mostrar_capa("ok")
            hora = datetime.now().strftime("%I:%M %p").lower()
            self.lbl_nombre_ok.config(text=nombre or "Usuario")
            self.lbl_info_ok.config(
                text=self._t("acceso.acceso_registrado", "Acceso registrado · ") + hora)
            c = self.canvas_foto
            c.delete("all")
            c.create_oval(5, 5, 115, 115, fill="#ffffff", outline="#c8f0c8", width=3)
            c.create_text(60, 60, text="👤", font=("Segoe UI", 40),
                          fill=p["acceso_ok_bg"])
            self._btn_volver_ok.place_forget()
            self._after_reset = self.canvas_icono.after(20000, self._fin_secuencia_ok)

        elif estado == "acceso_deny":
            threading.Thread(target=self._gpio_acceso_deny, daemon=True).start()
            # FIX: registrar acceso denegado en la base de datos
            threading.Thread(target=self._registrar_acceso_denegado_bd,
                              daemon=True).start()
            self._mostrar_capa("escaneo")

        else:
            self._mostrar_capa("escaneo")

    # ══════════════════════════════════════════
    #  GPIO
    # ══════════════════════════════════════════
    def _gpio_acceso_ok(self):
        try:
            from core.gpio import acceso_concedido
            acceso_concedido()
        except Exception as e:
            print(f"[GPIO] Error acceso_concedido: {e}")

    def _gpio_acceso_deny(self):
        try:
            from core.gpio import acceso_denegado
            acceso_denegado()
        except Exception as e:
            print(f"[GPIO] Error acceso_denegado: {e}")

    def _registrar_acceso_bd(self, cod: str):
        try:
            from core.database import registrar_acceso
            registrar_acceso(cod)
            print(f"[ACCESO] Acceso concedido registrado para: {cod}")
        except Exception as e:
            print(f"[ACCESO] Error registrando acceso concedido: {e}")

    # FIX: nuevo método para registrar acceso denegado
    def _registrar_acceso_denegado_bd(self):
        try:
            from core.database import registrar_acceso_denegado
            registrar_acceso_denegado(None)
            print("[ACCESO] Acceso denegado registrado en BD")
        except Exception as e:
            print(f"[ACCESO] Error registrando acceso denegado: {e}")

    # ══════════════════════════════════════════
    #  Animación
    # ══════════════════════════════════════════
    def _iniciar_animacion(self):
        self._animar()

    def _animar(self):
        self._angulo = (self._angulo + 4) % 360
        self._dibujar_icono()
        try:
            self._after_anim = self.canvas_icono.after(33, self._animar)
        except Exception:
            pass

    def _dibujar_icono(self):
        c = self.canvas_icono
        c.delete("all")
        p = self._p
        self._crear_rect_redondeado(c, 2, 2, 42, 42, 10, fill="#333333")
        cx, cy, r = 22, 22, 13
        grosor = 4

        if self._estado in ("escaneando", "sin_rostro", "sin_camara", "acceso_deny"):
            c.create_oval(cx-r, cy-r, cx+r, cy+r, outline="#555555", width=grosor)
            color_onda = "#ff0000" if self._estado == "acceso_deny" \
                         else p["acceso_barra_ok"]
            c.create_arc(cx-r, cy-r, cx+r, cy+r,
                         start=self._angulo, extent=240,
                         style="arc", outline=color_onda, width=grosor)
            for angulo in (self._angulo, self._angulo + 240):
                rad = math.radians(angulo)
                xp  = cx + r * math.cos(rad)
                yp  = cy - r * math.sin(rad)
                cr  = grosor / 2.0
                c.create_oval(xp-cr, yp-cr, xp+cr, yp+cr,
                              fill=color_onda, outline="")
        elif self._estado == "detectado":
            color_onda = p["acceso_barra_ok"]
            c.create_oval(cx-r, cy-r, cx+r, cy+r,
                          outline=color_onda, width=grosor, fill="#2d4a2d")
            c.create_oval(cx-5, cy-5, cx+5, cy+5, fill=color_onda, outline="")

    # ══════════════════════════════════════════
    #  Limpieza
    # ══════════════════════════════════════════
    def ignorar_cierre(self):
        pass

    def _volver(self):
        if hasattr(self.app, "tema"):
            self.app.tema.desregistrar(self._aplicar_tema)
        if hasattr(self.app, "idioma"):
            self.app.idioma.desregistrar(self._aplicar_idioma)
        self._corriendo = False
        if self._cap:
            self._cap.release()
        for aid in (self._after_anim, self._after_reset):
            if aid:
                try:
                    self.canvas_icono.after_cancel(aid)
                except Exception:
                    pass
        try:
            from core.gpio import apagar_todo
            apagar_todo()
        except Exception:
            pass
        ventana_principal = self.parent.winfo_toplevel()
        ventana_principal.protocol("WM_DELETE_WINDOW", ventana_principal.destroy)
        self.app.mostrar_pantalla("principal")


def _paleta_fallback() -> dict:
    return {
        "acceso_fondo":      "#000000",
        "acceso_ok_bg":      "#43A047",
        "acceso_ok_texto":   "#ffffff",
        "acceso_deny_texto": "#f44336",
        "acceso_hud_fg":     "#ffffff",
        "acceso_barra_ok":   "#4CAF50",
    }


def crear_pantalla_acceso(parent, app):
    PantallaAcceso(parent, app)